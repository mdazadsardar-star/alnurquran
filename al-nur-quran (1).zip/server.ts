import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize GoogleGenAI client securely on the server
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Resilient helper to call Gemini API with exponential backoff retries and model fallback
async function generateContentWithRetry(params: { contents: any; config?: any }) {
  // Try gemini-3.5-flash first, fallback to highly stable/high capacity gemini-flash-latest, then gemini-3.1-flash-lite
  const modelsToTry = ["gemini-3.5-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
  let lastError: any = null;

  for (const model of modelsToTry) {
    let delay = 500;
    const maxRetries = 2; // limit retries per model to keep responsiveness high

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`[Gemini API] Attempting model: ${model} (attempt ${attempt}/${maxRetries})`);
        const response = await ai.models.generateContent({
          model,
          contents: params.contents,
          config: params.config,
        });
        console.log(`[Gemini API] Success using model: ${model}`);
        return response;
      } catch (error: any) {
        lastError = error;
        const status = error?.status || error?.code || error?.statusCode;
        const message = error?.message || "";
        
        console.warn(`[Gemini API] Failed with model ${model} on attempt ${attempt}:`, message);

        // Check if error is transient / temporary high demand (e.g., status 503, 429)
        const isTransient = 
          status === 503 || 
          status === 429 || 
          message.includes("503") || 
          message.includes("temporary") || 
          message.includes("high demand") || 
          message.includes("overloaded") ||
          message.includes("UNAVAILABLE");

        // If it is 503 / high demand / UNAVAILABLE, it's better to immediately switch to another model
        // rather than retrying the overloaded one multiple times.
        const isOverloaded = 
          status === 503 || 
          message.includes("503") || 
          message.includes("temporary") || 
          message.includes("high demand") || 
          message.includes("overloaded") ||
          message.includes("UNAVAILABLE");

        if (isTransient && !isOverloaded && attempt < maxRetries) {
          console.log(`[Gemini API] Transient error (429/etc) detected. Retrying ${model} in ${delay}ms...`);
          await new Promise((resolve) => setTimeout(resolve, delay));
          delay *= 1.5; // exponential backoff
        } else {
          // Break inner loop to try the next fallback model immediately to minimize user wait time
          console.log(`[Gemini API] Failing over from ${model} immediately...`);
          break;
        }
      }
    }
  }

  throw lastError || new Error("All Gemini models failed to generate content.");
}

app.use(express.json());

// API route: Get spiritual insights for a verse
app.post("/api/gemini/insights", async (req, res) => {
  try {
    const { verseText, context } = req.body;
    if (!verseText) {
      return res.status(400).json({ error: "verseText is required" });
    }

    if (!apiKey) {
      return res.status(503).json({ error: "Gemini API key is not configured on the server." });
    }

    const response = await generateContentWithRetry({
      contents: `Provide a short, respectful spiritual insight or reflection on the following Quranic verse: "${verseText}" from Surah ${context}. Keep it concise and inspiring.`,
      config: {
        systemInstruction: "You are a respectful and knowledgeable Islamic scholar. Provide brief, uplifting reflections on Quranic verses.",
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Insights Error:", error);
    res.status(500).json({ error: error?.message || "Failed to get spiritual insights" });
  }
});

// API route: Search for verses related to a query
app.post("/api/gemini/search", async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) {
      return res.status(400).json({ error: "query is required" });
    }

    if (!apiKey) {
      return res.status(530).json({ error: "Gemini API key is not configured on the server." });
    }

    const response = await generateContentWithRetry({
      contents: `Help me find Quranic verses related to the topic: "${query}". Provide the Surah name and Verse number for at least 3 relevant verses.`,
      config: {
        systemInstruction: "You are an assistant for a Quran app. Help users find verses related to their queries.",
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Search Error:", error);
    res.status(500).json({ error: error?.message || "Failed to search verses" });
  }
});

// API route: Get Bengali pronunciation / transliteration
app.post("/api/gemini/pronunciation", async (req, res) => {
  try {
    const { arabicText } = req.body;
    if (!arabicText) {
      return res.status(400).json({ error: "arabicText is required" });
    }

    if (!apiKey) {
      return res.status(503).json({ error: "Gemini API key is not configured on the server." });
    }

    const response = await generateContentWithRetry({
      contents: `Provide the exact Bengali pronunciation (transliteration) for this Arabic text: "${arabicText}". Only return the Bengali text, nothing else.`,
      config: {
        systemInstruction: "You are an expert in Arabic to Bengali transliteration. Provide accurate Bengali pronunciation of Quranic Arabic.",
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Pronunciation Error:", error);
    res.status(500).json({ error: error?.message || "Failed to get pronunciation" });
  }
});

// Vite middleware integration
async function integrateVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

integrateVite();
