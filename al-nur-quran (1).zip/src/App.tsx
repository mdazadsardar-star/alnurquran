import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Book, Search as SearchIcon, Headphones, Info, ChevronLeft, Play, Pause, X, Menu, Loader2, Settings as SettingsIcon, Heart, Share2, Trash2, LayoutGrid, Tag, Sun, Moon, Monitor, Globe, ChevronDown, Mic, Facebook, Twitter, Mail, MessageCircle, Folder, Volume2 } from 'lucide-react';
import { quranApi, Surah, Verse } from '@/src/services/quranApi';
import { geminiService } from '@/src/services/geminiService';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';

const TOPICS = [
  {
    id: 1,
    topic: "তাওহীদ (Monotheism)",
    surah: "সূরা ইখলাস ১",
    arabic: "قُلْ هُوَ اللَّهُ أَحَدٌ",
    bangla: "বলুন, তিনি আল্লাহ, একক।",
    color: "bg-blue-50 text-blue-700"
  },
  {
    id: 2,
    topic: "সবর (Patience)",
    surah: "সূরা বাকারা ১৫৩",
    arabic: "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
    bangla: "নিশ্চয়ই আল্লাহ ধৈর্যশীলদের সাথে আছেন।",
    color: "bg-emerald-50 text-emerald-700"
  },
  {
    id: 3,
    topic: "নামাজ (Prayer)",
    surah: "সূরা বাকারা ৪৩",
    arabic: "وَأَقِيمُوا الصَّلَاةَ",
    bangla: "তোমরা সালাত প্রতিষ্ঠা কর।",
    color: "bg-amber-50 text-amber-700"
  },
  {
    id: 4,
    topic: "তাকওয়া (Piety)",
    surah: "সূরা আল-হুজরাত ১৩",
    arabic: "إِنَّ أَكْرَمَكُمْ عِندَ اللَّهِ أَتْقَاكُمْ",
    bangla: "নিশ্চয়ই আল্লাহ তোমাদের মধ্যে সেই ব্যক্তিকে সর্বাধিক সম্মান দেন যে তোমাদের মধ্যে সবচেয়ে চরিত্রবান বা পরহেজগার।",
    color: "bg-purple-50 text-purple-700"
  },
  {
    id: 5,
    topic: "মা-বাবার সেবা (Parents)",
    surah: "সূরা বনী ইসরাঈল ২৩",
    arabic: "وَبِالْوَالِدَيْنِ إِحْسَانًا",
    bangla: "এবং তোমরা তোমাদের পিতামাতার সাথে সদাচরণ করো।",
    color: "bg-rose-50 text-rose-700"
  },
  {
    id: 6,
    topic: "ক্ষমা (Forgiveness)",
    surah: "সূরা আলে ইমরান ১৩৩",
    arabic: "وَسَارِعُوا إِلَىٰ مَغْفِرَةٍ مِّن رَّبِّكُمْ",
    bangla: "এবং তোমরা তোমাদের প্রতিপালকের ক্ষমা ও সেই জান্নাতের দিকে দ্রুত অগ্রসর হও যার প্রশস্ততা আসমান ও যমীনের ন্যায়।",
    color: "bg-indigo-50 text-indigo-700"
  }
];

export default function App() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [translationId, setTranslationId] = useState<number | string>(162); // Default to Bengali
  const [loadingSurahs, setLoadingSurahs] = useState(true);
  const [loadingVerses, setLoadingVerses] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [topicSearchTerm, setTopicSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('surahs');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null);
  const [playingVerseKey, setPlayingVerseKey] = useState<string | null>(null);
  const [currentVerseAudio, setCurrentVerseAudio] = useState<HTMLAudioElement | null>(null);
  const [isVersePlaying, setIsVersePlaying] = useState(false);
  const [reflection, setReflection] = useState<{ [key: number]: string }>({});
  const [loadingReflection, setLoadingReflection] = useState<{ [key: number]: boolean }>({});
  const [pronunciation, setPronunciation] = useState<{ [key: number]: string }>({});
  const [loadingPronunciation, setLoadingPronunciation] = useState<{ [key: number]: boolean }>({});
  const [geminiSearchResult, setGeminiSearchResult] = useState<string | null>(null);
  const [searchingAI, setSearchingAI] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [theme, setTheme] = useState<'Light' | 'Dark' | 'Auto'>('Auto');
  const [language, setLanguage] = useState<'English' | 'Español' | 'Français' | 'Bangla'>('English');
  const [showBengaliCollection, setShowBengaliCollection] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [blessingsCount, setBlessingsCount] = useState(() => {
    const saved = localStorage.getItem('al-nur-blessings');
    return saved ? parseInt(saved, 10) : 313;
  });

  const sendBlessing = () => {
    const newCount = blessingsCount + 1;
    setBlessingsCount(newCount);
    localStorage.setItem('al-nur-blessings', newCount.toString());
  };

  // Language Sync
  useEffect(() => {
    if (language === 'Bangla') {
      setTranslationId(162); // Default to Rawai Al-bayan
    } else if (language === 'English') {
      setTranslationId(131); // Default to Sahih
    }
  }, [language]);

  const toggleBengaliCollection = () => {
    if (!showBengaliCollection) {
      setTranslationId('161,162,163,213');
      setShowBengaliCollection(true);
    } else {
      setTranslationId(162);
      setShowBengaliCollection(false);
    }
  };

  // Clock Effect
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Theme Effect
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');

    if (theme === 'Auto') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme.toLowerCase());
    }
  }, [theme]);

  // Settings State
  const [arabicFontSize, setArabicFontSize] = useState(48);

  const safeAlert = (message: string) => {
    try {
      window.alert(message);
    } catch (e) {
      console.warn("Alert blocked or failed, message:", message, e);
    }
  };
  const [translationFontSize, setTranslationFontSize] = useState(18);
  const [reciterSlug, setReciterSlug] = useState('mishari_rashid_al-afasy');
  const [showWordByWord, setShowWordByWord] = useState(true);
  const [wordColor, setWordColor] = useState('#0d9488');
  const [bookmarks, setBookmarks] = useState<{ id: string, surahName: string, verseNumber: number, text: string }[]>([]);

  // Load from localStorage
  useEffect(() => {
    const savedBookmarks = localStorage.getItem('al-nur-bookmarks');
    if (savedBookmarks) {
      try {
        setBookmarks(JSON.parse(savedBookmarks));
      } catch (e) {
        console.error("Failed to parse saved bookmarks:", e);
      }
    }

    const savedSettings = localStorage.getItem('al-nur-settings');
    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings);
        if (settings.arabicFontSize) setArabicFontSize(settings.arabicFontSize);
        if (settings.translationFontSize) setTranslationFontSize(settings.translationFontSize);
        if (settings.reciterSlug) setReciterSlug(settings.reciterSlug);
        if (settings.showWordByWord !== undefined) setShowWordByWord(settings.showWordByWord);
        if (settings.wordColor) setWordColor(settings.wordColor);
      } catch (e) {
        console.error("Failed to parse saved settings:", e);
      }
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('al-nur-bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  useEffect(() => {
    localStorage.setItem('al-nur-settings', JSON.stringify({
      arabicFontSize,
      translationFontSize,
      reciterSlug,
      showWordByWord,
      wordColor
    }));
  }, [arabicFontSize, translationFontSize, reciterSlug, showWordByWord, wordColor]);

  const toggleBookmark = (verse: Verse, surahName: string) => {
    const id = `${selectedSurah?.id}:${verse.verse_number}`;
    const exists = bookmarks.find(b => b.id === id);
    if (exists) {
      setBookmarks(bookmarks.filter(b => b.id !== id));
    } else {
      setBookmarks([...bookmarks, {
        id,
        surahName,
        verseNumber: verse.verse_number,
        text: verse.text_uthmani
      }]);
    }
  };

  const isBookmarked = (verseId: number) => {
    const id = `${selectedSurah?.id}:${verses.find(v => v.id === verseId)?.verse_number}`;
    return bookmarks.some(b => b.id === id);
  };

  useEffect(() => {
    async function init() {
      try {
        const data = await quranApi.getSurahs();
        setSurahs(data);
      } catch (error) {
        console.error("Failed to fetch surahs", error);
      } finally {
        setLoadingSurahs(false);
      }
    }
    init();
  }, []);

  const handleAISearch = async () => {
    if (!searchTerm.trim()) return;
    setSearchingAI(true);
    setActiveTab('search');
    try {
      const result = await geminiService.searchVerses(searchTerm);
      setGeminiSearchResult(result);
    } catch (error) {
      console.error("AI Search failed", error);
      setGeminiSearchResult("I encountered an error while searching. Please try again or browse chapters directly.");
    } finally {
      setSearchingAI(false);
    }
  };

  const handleDailyVerse = async () => {
    const randomSurahId = Math.floor(Math.random() * 114) + 1;
    const surah = surahs.find(s => s.id === randomSurahId) || surahs[0];
    setSelectedSurah(surah);
  };

  useEffect(() => {
    if (selectedSurah) {
      async function fetchVerses() {
        setLoadingVerses(true);
        try {
          const data = await quranApi.getVerses(selectedSurah.id, translationId);
          setVerses(data || []);
          setAudioUrl(quranApi.getAudioUrl(selectedSurah.id, reciterSlug));
        } catch (error) {
          console.error("Failed to fetch verses", error);
        } finally {
          setLoadingVerses(false);
        }
      }
      fetchVerses();
    }
  }, [selectedSurah, translationId, reciterSlug]);

  const toggleAudio = () => {
    if (!audioUrl) return;

    if (currentVerseAudio) {
      currentVerseAudio.pause();
      setIsVersePlaying(false);
      setPlayingVerseKey(null);
    }

    if (currentAudio) {
      currentAudio.pause();
      currentAudio.src = audioUrl;
      currentAudio.load();
    }

    if (!currentAudio || currentAudio.src !== audioUrl) {
      const audio = new Audio(audioUrl);
      audio.onended = () => setIsPlaying(false);
      setCurrentAudio(audio);
      audio.play();
      setIsPlaying(true);
    } else {
      if (isPlaying) {
        currentAudio.pause();
        setIsPlaying(false);
      } else {
        currentAudio.play();
        setIsPlaying(true);
      }
    }
  };

  const toggleVerseAudio = (verseKey: string, verseNumber: number) => {
    if (!selectedSurah) return;

    if (currentAudio) {
      currentAudio.pause();
      setIsPlaying(false);
    }

    const verseAudioUrl = quranApi.getVerseAudioUrl(selectedSurah.id, verseNumber, reciterSlug);

    if (currentVerseAudio && playingVerseKey === verseKey) {
      if (isVersePlaying) {
        currentVerseAudio.pause();
        setIsVersePlaying(false);
      } else {
        currentVerseAudio.play();
        setIsVersePlaying(true);
      }
    } else {
      if (currentVerseAudio) {
        currentVerseAudio.pause();
      }

      const audio = new Audio(verseAudioUrl);
      audio.onended = () => {
        setIsVersePlaying(false);
        setPlayingVerseKey(null);
      };

      setCurrentVerseAudio(audio);
      setPlayingVerseKey(verseKey);
      audio.play().then(() => {
        setIsVersePlaying(true);
      }).catch(err => {
        console.error("Failed to play verse audio:", err);
      });
    }
  };

  // Turn off any playing audio on Surah switches or component unmounts
  useEffect(() => {
    return () => {
      if (currentAudio) {
        currentAudio.pause();
      }
      if (currentVerseAudio) {
        currentVerseAudio.pause();
      }
    };
  }, [selectedSurah]);

  const handleReflect = async (verseId: number, text: string, context: string) => {
    setLoadingReflection(prev => ({ ...prev, [verseId]: true }));
    const insight = await geminiService.getInsights(text, context);
    if (insight) {
      setReflection(prev => ({ ...prev, [verseId]: insight }));
    } else {
      setReflection(prev => ({ ...prev, [verseId]: "স্পিরিচুয়াল রিফ্লেকশন লোড করা সম্ভব হয়নি। অনুগ্রহ করে একটু পর আবার চেষ্টা করুন।" }));
    }
    setLoadingReflection(prev => ({ ...prev, [verseId]: false }));
  };

  const handlePronunciation = async (verseId: number, text: string) => {
    // If there is already a pronunciation and it's not an error message, we don't need to load again
    if (pronunciation[verseId] && !pronunciation[verseId].startsWith("ত্রুটি:")) return;
    setLoadingPronunciation(prev => ({ ...prev, [verseId]: true }));
    const result = await geminiService.getPronunciation(text);
    if (result) {
      setPronunciation(prev => ({ ...prev, [verseId]: result }));
    } else {
      setPronunciation(prev => ({ ...prev, [verseId]: "ত্রুটি: উচ্চারণ লোড করা সম্ভব হয়নি। অনুগ্রহ করে আবার চেষ্টা করুন।" }));
    }
    setLoadingPronunciation(prev => ({ ...prev, [verseId]: false }));
  };

  const filteredSurahs = surahs.filter(s =>
    s.name_simple.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.name_arabic.includes(searchTerm) ||
    s.translated_name.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-[#c0a66d] selection:text-white">
      {/* Sidebar / Header Navigation */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
              <div className="flex items-center gap-3 cursor-pointer" onClick={() => { setSelectedSurah(null); setActiveTab('surahs'); }}>
            <div className="w-10 h-10 bg-[#1d4ed8] rounded-xl flex items-center justify-center text-white shadow-lg">
              <Book size={22} fill="currentColor" />
            </div>
            <div>
              <h1 className="font-bold text-2xl tracking-tight"><span className="text-[#1d4ed8]">Al-Nur</span> <span className="text-[#f97316]">Quran</span></h1>
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Illuminate Your Heart</p>
            </div>
          </div>

            <div className="hidden md:flex items-center bg-muted/50 rounded-full px-4 py-2 w-1/3 border group focus-within:border-[#f97316] focus-within:ring-2 focus-within:ring-[#f97316]/20 transition-all">
            <SearchIcon size={18} className="text-muted-foreground shrink-0" />
            <input
              type="text"
              id="searchInput"
              placeholder="Search..."
              className="bg-transparent border-none focus:ring-0 w-full px-3 text-sm outline-none"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                if (e.target.value && (selectedSurah || activeTab !== 'surahs')) {
                  setSelectedSurah(null);
                  setActiveTab('surahs');
                }
              }}
              onKeyDown={(e) => e.key === 'Enter' && handleAISearch()}
            />
            <Button variant="default" size="sm" onClick={handleAISearch} disabled={searchingAI} className="h-8 rounded-full text-xs font-bold shrink-0 bg-[#1d4ed8] hover:bg-[#1e40af] text-white">
              {searchingAI ? <Loader2 size={12} className="animate-spin mr-1" /> : null}
              Search
            </Button>
          </div>

            <div className="flex items-center gap-4">
              <Dialog>
                <DialogTrigger render={<Button variant="ghost" size="icon" className="rounded-full text-[#1d4ed8] hover:bg-[#eff6ff]" />}>
                   <Share2 size={20} />
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] rounded-[2.5rem] p-8">
                  <DialogHeader className="text-center">
                    <DialogTitle className="text-3xl font-serif font-black mb-2 text-center">Share Al-Nur Quran</DialogTitle>
                    <DialogDescription className="text-center text-muted-foreground">Share the light of Quran with your loved ones.</DialogDescription>
                  </DialogHeader>
                  <div className="flex justify-center flex-wrap gap-6 py-8">
                    {[
                      { 
                        name: 'Facebook', 
                        icon: <Facebook size={24} />, 
                        color: 'bg-[#1877f2]', 
                        url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}` 
                      },
                      { 
                        name: 'Email', 
                        icon: <Mail size={24} />, 
                        color: 'bg-[#ea4335]', 
                        url: `mailto:?subject=Experience the Holy Quran with Al-Nur&body=Check out this beautiful Quran application: ${encodeURIComponent(window.location.href)}` 
                      },
                      { 
                        name: 'X (Twitter)', 
                        icon: <Twitter size={24} />, 
                        color: 'bg-[#000000]', 
                        url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=I'm using Al-Nur Quran to study and reflect on the Holy Quran. Check it out!` 
                      },
                      { 
                        name: 'WhatsApp', 
                        icon: <MessageCircle size={24} />, 
                        color: 'bg-[#25d366]', 
                        url: `https://api.whatsapp.com/send?text=Check out the Al-Nur Quran App: ${encodeURIComponent(window.location.href)}` 
                      },
                    ].map((platform) => (
                      <a
                        key={platform.name}
                        href={platform.url}
                        target="_blank"
                        rel="noreferrer"
                        className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg transition-all hover:scale-110 hover:opacity-90 ${platform.color}`}
                        title={`Share on ${platform.name}`}
                      >
                        {platform.icon}
                      </a>
                    ))}
                  </div>
                  <div className="bg-muted/30 p-4 rounded-2xl flex items-center justify-between gap-4">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground truncate flex-1">
                      {window.location.href}
                    </p>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="rounded-xl text-[10px] uppercase font-bold text-[#1d4ed8]"
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.href);
                        safeAlert("App link copied!");
                      }}
                    >
                      Copy Link
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              {/* Theme Dropdown */}
              <div className="relative group hidden sm:block" id="theme-dropdown">
                <Button variant="ghost" className="rounded-full gap-2 text-xs font-bold uppercase tracking-widest h-10 px-4 bg-muted/30">
                  {theme === 'Light' && <Sun size={14} className="text-amber-500" />}
                  {theme === 'Dark' && <Moon size={14} className="text-indigo-400" />}
                  {theme === 'Auto' && <Monitor size={14} className="text-muted-foreground" />}
                  <span>{theme}</span>
                  <ChevronDown size={12} className="text-muted-foreground group-hover:rotate-180 transition-transform" />
                </Button>
                <div className="absolute top-full right-0 mt-2 w-32 bg-card rounded-2xl shadow-xl border border-muted p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                  {(['Light', 'Dark', 'Auto'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setTheme(t)}
                      className={`w-full text-left px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-muted transition-colors ${theme === t ? 'text-[#1d4ed8] bg-[#eff6ff]' : ''}`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Language Dropdown */}
              <div className="relative group hidden sm:block" id="lang-dropdown">
                <Button variant="ghost" className="rounded-full gap-2 text-xs font-bold uppercase tracking-widest h-10 px-4 bg-muted/30">
                  <Globe size={14} className="text-muted-foreground" />
                  <span>{language}</span>
                  <ChevronDown size={12} className="text-muted-foreground group-hover:rotate-180 transition-transform" />
                </Button>
                <div className="absolute top-full right-0 mt-2 w-36 bg-card rounded-2xl shadow-xl border border-muted p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                  {(['English', 'Español', 'Français', 'Bangla'] as const).map((l) => (
                    <button
                      key={l}
                      onClick={() => setLanguage(l)}
                      className={`w-full text-left px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-muted transition-colors ${language === l ? 'text-[#1d4ed8] bg-[#eff6ff]' : ''}`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>

              <Dialog>
                <DialogTrigger render={<Button variant="ghost" size="icon" className="md:hidden rounded-full text-[#1d4ed8]" />}>
                  <SearchIcon size={20} />
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] rounded-[2rem] top-[20%]">
                  <DialogHeader>
                    <DialogTitle>Search Quran</DialogTitle>
                  </DialogHeader>
                  <div className="flex flex-col gap-4 py-4">
                    <div className="relative">
                      <SearchIcon size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search chapters or AI..."
                        className="pl-10 rounded-xl"
                        value={searchTerm}
                        onChange={(e) => {
                          setSearchTerm(e.target.value);
                          if (e.target.value && (selectedSurah || activeTab !== 'surahs')) {
                            setSelectedSurah(null);
                            setActiveTab('surahs');
                          }
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && handleAISearch()}
                      />
                    </div>
                    <Button onClick={handleAISearch} disabled={searchingAI} className="w-full rounded-xl bg-[#1d4ed8]">
                      {searchingAI ? <Loader2 size={16} className="animate-spin mr-2" /> : <SearchIcon size={16} className="mr-2" />}
                      AI Search
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog>
              <DialogTrigger render={<Button variant="ghost" size="icon" className="rounded-full text-[#1d4ed8] hover:bg-[#eff6ff]" />}>
                <SettingsIcon size={20} />
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px] rounded-[2rem]">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-serif">Settings</DialogTitle>
                  <DialogDescription>Customize your reading and listening experience.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="space-y-3">
                    <label className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Arabic Font Size ({arabicFontSize}px)</label>
                    <Slider
                      value={[arabicFontSize]}
                      min={24}
                      max={84}
                      step={2}
                      onValueChange={(val) => setArabicFontSize(val[0])}
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Translation Font Size ({translationFontSize}px)</label>
                    <Slider
                      value={[translationFontSize]}
                      min={12}
                      max={40}
                      step={1}
                      onValueChange={(val) => setTranslationFontSize(val[0])}
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Reciter</label>
                    <Select value={reciterSlug} onValueChange={setReciterSlug}>
                      <SelectTrigger className="w-full rounded-xl">
                        <SelectValue placeholder="Select Reciter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mishari_rashid_al-afasy">Mishary Rashid Alafasy</SelectItem>
                        <SelectItem value="abdul_basit_murattal">AbdulBaset AbdulSamad (Murattal)</SelectItem>
                        <SelectItem value="abdurrahmaan_as-sudays">Abdur-Rahman as-Sudais</SelectItem>
                        <SelectItem value="abu_bakr_al-shatri">Abu Bakr al-Shatri</SelectItem>
                        <SelectItem value="ahmed_ibn_ali_al-ajamy">Ahmed Al-Ajamy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Word-by-Word Meanings</label>
                    <Switch
                      checked={showWordByWord}
                      onCheckedChange={setShowWordByWord}
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Word Translation Color</label>
                    <div className="flex gap-3">
                      {[
                        { name: 'Teal', value: '#0d9488' },
                        { name: 'Blue', value: '#2563eb' },
                        { name: 'Red', value: '#dc2626' },
                        { name: 'Pink', value: '#db2777' },
                        { name: 'Indigo', value: '#4f46e5' }
                      ].map((c) => (
                        <button
                          key={c.value}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${wordColor === c.value ? 'border-black scale-110' : 'border-transparent'}`}
                          style={{ backgroundColor: c.value }}
                          onClick={() => setWordColor(c.value)}
                          title={c.name}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog>
              <DialogTrigger render={<Button variant="ghost" size="icon" className="rounded-full text-[#f97316] hover:bg-[#fff7ed]" />}>
                <Heart size={20} />
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px] rounded-[2rem]">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-serif">Bookmarks</DialogTitle>
                </DialogHeader>
                <ScrollArea className="h-[300px] pr-4">
                  {bookmarks.length === 0 ? (
                    <p className="text-center text-muted-foreground py-10">No bookmarks yet.</p>
                  ) : (
                    <div className="space-y-4">
                      {bookmarks.map((bookmark) => (
                        <Card key={bookmark.id} className="border-none bg-muted/30 p-4 rounded-2xl relative group">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-destructive"
                            onClick={() => setBookmarks(bookmarks.filter(b => b.id !== bookmark.id))}
                          >
                            <Trash2 size={14} />
                          </Button>
                          <div className="flex items-center gap-2 mb-2">
                             <Badge variant="outline" className="text-[10px] uppercase">{bookmark.surahName}</Badge>
                             <span className="text-[10px] font-bold text-muted-foreground">Verse {bookmark.verseNumber}</span>
                          </div>
                          <p className="font-arabic text-xl text-right leading-relaxed">{bookmark.text}</p>
                        </Card>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </DialogContent>
            </Dialog>

            <Dialog open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <DialogTrigger render={<Button variant="ghost" size="icon" className="md:hidden" />}>
                <Menu size={24} />
              </DialogTrigger>
              <DialogContent className="sm:max-w-[300px] rounded-[2rem]">
                <DialogHeader>
                  <DialogTitle className="text-xl font-bold">Navigation</DialogTitle>
                </DialogHeader>
                <div className="flex flex-col gap-2 py-4">
                  <div className="px-4 py-2">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-3">Settings</p>
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between p-2 bg-muted/20 rounded-xl">
                        <span className="text-xs font-bold uppercase tracking-widest">Theme</span>
                        <div className="flex gap-1">
                          {(['Light', 'Dark', 'Auto'] as const).map((t) => (
                            <Button 
                              key={t}
                              variant="ghost" 
                              size="sm" 
                              className={`rounded-lg px-2 h-8 text-[10px] font-bold uppercase ${theme === t ? 'bg-background shadow-sm text-[#1d4ed8]' : ''}`}
                              onClick={() => setTheme(t)}
                            >
                              {t}
                            </Button>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-muted/20 rounded-xl">
                        <span className="text-xs font-bold uppercase tracking-widest">Language</span>
                        <Select value={language} onValueChange={(val: any) => setLanguage(val)}>
                          <SelectTrigger className="h-8 w-24 rounded-lg text-[10px] font-bold uppercase">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="English">English</SelectItem>
                            <SelectItem value="Español">Español</SelectItem>
                            <SelectItem value="Français">Français</SelectItem>
                            <SelectItem value="Bangla">Bangla</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <div className="h-px bg-muted mx-4 my-2" />
                  <Button 
                    variant="ghost" 
                    className={`justify-start rounded-xl p-4 h-14 ${activeTab === 'surahs' ? 'bg-[#eff6ff] text-[#1d4ed8]' : ''}`}
                    onClick={() => { setSelectedSurah(null); setActiveTab('surahs'); setMobileMenuOpen(false); }}
                  >
                    <Book className="mr-3" size={20} /> Chapters
                  </Button>
                  <Button 
                    variant="ghost" 
                    className={`justify-start rounded-xl p-4 h-14 ${activeTab === 'topics' ? 'bg-[#fff7ed] text-[#f97316]' : ''}`}
                    onClick={() => { setSelectedSurah(null); setActiveTab('topics'); setMobileMenuOpen(false); }}
                  >
                    <LayoutGrid className="mr-3" size={20} /> Topics
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="justify-start rounded-xl p-4 h-14"
                    onClick={() => { handleDailyVerse(); setMobileMenuOpen(false); }}
                  >
                    <Heart className="mr-3 text-red-500" size={20} /> Daily Verse
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <div className="hidden md:flex items-center gap-2">
               <Button variant="ghost" className={`rounded-full text-sm font-medium ${activeTab === 'surahs' ? 'text-[#1d4ed8] bg-[#eff6ff]' : ''}`} onClick={() => { setSelectedSurah(null); setActiveTab('surahs'); }}>Chapters</Button>
               <Button variant="ghost" className={`rounded-full text-sm font-medium ${activeTab === 'topics' ? 'text-[#f97316] bg-[#fff7ed]' : ''}`} onClick={() => { setSelectedSurah(null); setActiveTab('topics'); }}>Topics</Button>
               <Button variant="ghost" className="rounded-full text-sm font-medium" onClick={handleDailyVerse}>Daily Verse</Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 text-[#b50412]">
        {/* Live Prayer Header */}
        {!selectedSurah && activeTab === 'surahs' && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12 rounded-[2rem] overflow-hidden bg-gradient-to-br from-[#121212] to-[#1a1a1a] shadow-2xl border border-white/5"
          >
            <div className="p-8 md:p-12 relative">
              {/* Pattern Overlay */}
              <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
              
              <div className="relative z-10 flex flex-col gap-8">
                {/* Search Bar */}
                <div className="relative max-w-xl">
                  <SearchIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-300/60" />
                  <Input 
                    placeholder="Search for a city..." 
                    className="pl-12 h-12 bg-emerald-950/40 border-emerald-900/50 text-emerald-100 placeholder:text-emerald-300/30 rounded-xl focus-visible:ring-emerald-500/30 focus-visible:border-emerald-500/50 transition-all border-2"
                  />
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 items-center gap-8 text-white">
                  {/* Left: Dates */}
                  <div className="space-y-1 text-center md:text-left">
                    <p className="text-lg font-medium tracking-tight">
                      {currentTime.toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' })}
                    </p>
                    <p className="text-xs text-white/50 uppercase tracking-widest font-bold">
                      {new Intl.DateTimeFormat('en-u-ca-islamic-uma', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(currentTime)}
                    </p>
                  </div>

                  {/* Center: Live Clock */}
                  <div className="text-center">
                    <p 
                      style={{ color: '#0029d4', height: '53px', borderRadius: '-10px' }}
                      className="text-6xl md:text-7xl font-sans font-light tracking-widest drop-shadow-[0_0_15px_rgba(52,211,153,0.3)]"
                    >
                      {currentTime.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </p>
                  </div>

                  {/* Right: Location/Method */}
                  <div className="space-y-1 text-center md:text-right">
                    <div className="flex items-center justify-center md:justify-end gap-2 text-lg">
                      <Globe size={18} className="text-emerald-500" />
                      <span className="font-medium">Prayer times for Durgapur, India</span>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {selectedSurah ? (
            <motion.div
              key="surah-view"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8 pb-32"
            >
              <div className="flex items-center justify-between mb-6">
                <Button variant="outline" size="sm" onClick={() => setSelectedSurah(null)} className="rounded-full gap-2 text-xs font-semibold">
                  <ChevronLeft size={16} /> Back to Chapters
                </Button>
                <div className="flex items-center gap-3">
                  {language === 'Bangla' && (
                    <Button 
                      variant={showBengaliCollection ? "default" : "outline"} 
                      size="sm" 
                      onClick={toggleBengaliCollection}
                      className={`rounded-full gap-2 text-[10px] font-bold uppercase tracking-widest ${showBengaliCollection ? 'bg-[#f97316] text-white hover:bg-[#ea580c] border-none' : 'border-[#f97316]/30 text-[#f97316] hover:bg-[#fff7ed]'}`}
                    >
                      <Folder size={12} />
                      নতুন ফোল্ডার (Collection)
                    </Button>
                  )}
                  <Select value={translationId.toString()} onValueChange={(val) => {
                    setTranslationId(val.includes(',') ? val : parseInt(val));
                    setShowBengaliCollection(val.includes(','));
                  }}>
                    <SelectTrigger className="w-[180px] rounded-full h-8 text-[10px] font-bold uppercase tracking-widest border-[#1d4ed8]/20">
                      <SelectValue placeholder="Language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="131">English (Sahih)</SelectItem>
                      <SelectItem value="162">Bengali (Rawai Al-bayan)</SelectItem>
                      <SelectItem value="161">Bengali (Taisirul Quran)</SelectItem>
                      <SelectItem value="163">Bengali (Mujibur Rahman)</SelectItem>
                      <SelectItem value="213">Bengali (Abu Bakr Zakaria)</SelectItem>
                      <SelectItem value="161,162,163,213" className="text-[#f97316] font-bold">Bengali Collection (ফোল্ডার)</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="ghost" size="icon" className="rounded-full" onClick={toggleAudio}>
                    {isPlaying ? <Pause size={20} className="text-[#f97316]" /> : <Play size={20} className="text-[#f97316]" />}
                  </Button>
                </div>
              </div>

              <div className="text-center py-16 px-4 bg-muted/30 rounded-[40px] mb-12 relative overflow-hidden">
                <div className="relative z-10">
                   <p className="text-[#1d4ed8] font-bold text-sm uppercase tracking-[0.2em] mb-4">Surah</p>
                   <h2 className="text-5xl md:text-7xl font-serif font-black mb-4 tracking-tighter">{selectedSurah.name_simple}</h2>
                   <p className="text-3xl text-muted-foreground font-arabic mb-6">{selectedSurah.name_arabic}</p>
                   <div className="flex items-center justify-center gap-6 text-xs font-bold text-muted-foreground/60 uppercase tracking-widest">
                     <span>{selectedSurah.revelation_place}</span>
                     <span className="w-1 h-1 bg-[#f97316] rounded-full" />
                     <span>{selectedSurah.verses_count} Verses</span>
                   </div>
                </div>
                 {/* Decorative Background */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]">
                   <span className="text-[20rem] font-serif font-bold italic">{selectedSurah.id}</span>
                </div>
              </div>

              {selectedSurah.bismillah_pre && (
                 <div className="text-center py-10">
                    <p className="font-arabic text-4xl text-foreground/90">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
                 </div>
              )}

              <div className="max-w-4xl mx-auto space-y-16">
                {loadingVerses ? (
                   Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="space-y-4">
                      <Skeleton className="h-10 w-full rounded-lg" />
                      <Skeleton className="h-6 w-3/4 rounded-lg" />
                    </div>
                  ))
                ) : (
                  verses.map((verse) => (
                    <motion.div
                      key={verse.id}
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      className="group relative"
                    >
                      <div className="absolute -left-12 top-0 h-full hidden lg:flex flex-col items-center">
                        <div className="w-8 h-8 rounded-full border-2 border-muted flex items-center justify-center text-[10px] font-bold text-muted-foreground group-hover:border-[#f97316] group-hover:text-[#f97316] transition-colors">
                          {verse.verse_number}
                        </div>
                        <div className="flex-1 w-px bg-muted mt-2 group-hover:bg-[#f97316]/50 transition-colors" />
                      </div>

                      <div className="space-y-8">
                        <div className="flex flex-wrap justify-end gap-x-6 gap-y-10" dir="rtl">
                          {verse.words?.map((word, i) => (
                            <div key={i} className="flex flex-col items-center group/word">
                              <p 
                                className="font-arabic leading-relaxed text-foreground hover:text-[#f97316] transition-all cursor-default"
                                style={{ fontSize: `${arabicFontSize}px` }}
                              >
                                {word.text_uthmani}
                              </p>
                              {showWordByWord && word.translation && (
                                <p 
                                  className="font-medium opacity-100 mt-2 transition-all text-center"
                                  style={{ fontSize: `${translationFontSize}px`, color: wordColor }}
                                >
                                  {word.translation.text}
                                </p>
                              )}
                            </div>
                          ))}
                          <div className="w-12 h-12 rounded-full border border-muted text-[10px] flex items-center justify-center font-bold text-muted-foreground self-start lg:hidden">
                            {verse.verse_number}
                          </div>
                        </div>

                        {verse.translations && verse.translations.length > 0 && (
                          <div className="bg-card/30 p-8 rounded-[2.5rem] border border-transparent shadow-sm">
                             <div className="space-y-4">
                               {verse.translations && verse.translations.map((t, idx) => {
                                 const authors: {[key: number]: string} = {
                                   161: 'Taisirul Quran',
                                   162: 'Rawai Al-bayan',
                                   163: 'Sheikh Mujibur Rahman',
                                   213: 'Dr. Abu Bakr Muhammad Zakaria',
                                   131: 'Sahih International'
                                 };
                                 const isCollection = verse.translations && verse.translations.length > 1;
                                 return (
                                   <div 
                                      key={idx} 
                                      className={`p-5 rounded-r-xl transition-all duration-300 ${isCollection ? 'bg-[#fafafa] dark:bg-muted/20 border-l-[4px] border-[#16a085] hover:translate-x-1 hover:bg-[#f5f9f8] dark:hover:bg-muted/40' : ''}`}
                                   >
                                     {isCollection && (
                                       <p className="text-[10px] font-black uppercase tracking-widest text-[#16a085] mb-2 opacity-80">
                                         — {authors[t.resource_id] || 'Translation'}
                                       </p>
                                     )}
                                     <p 
                                       className="text-muted-foreground leading-relaxed font-normal"
                                       style={{ fontSize: `${translationFontSize + (isCollection ? 0 : 2)}px` }}
                                     >
                                       {t.text.replace(/<(?:.|\n)*?>/gm, '')}
                                     </p>
                                   </div>
                                 );
                               })}
                             </div>

                             <div className="mt-6 flex items-center justify-between">
                               <div className="flex items-center gap-3">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className={`rounded-full text-[10px] font-bold uppercase tracking-widest ${playingVerseKey === verse.verse_key && isVersePlaying ? 'text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10' : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10'}`}
                                    onClick={() => toggleVerseAudio(verse.verse_key, verse.verse_number)}
                                  >
                                    {playingVerseKey === verse.verse_key && isVersePlaying ? (
                                      <Pause size={14} className="mr-2 animate-pulse" />
                                    ) : (
                                      <Volume2 size={14} className="mr-2" />
                                    )}
                                    {playingVerseKey === verse.verse_key && isVersePlaying ? 'Pause' : (language === 'Bangla' ? 'শুনুন (Listen)' : 'Listen')}
                                  </Button>
                                 <Button
                                   variant="ghost"
                                   size="sm"
                                   className="rounded-full text-[10px] font-bold uppercase tracking-widest text-[#1d4ed8]"
                                   onClick={() => handleReflect(verse.id, verse.text_uthmani, selectedSurah.name_simple)}
                                   disabled={loadingReflection[verse.id]}
                                 >
                                   {loadingReflection[verse.id] ? <Loader2 className="animate-spin mr-2" size={14} /> : <Headphones size={14} className="mr-2" />}
                                   Seek Insight
                                 </Button>
                                 <Button
                                   variant="ghost"
                                   size="sm"
                                   className="rounded-full text-[10px] font-bold uppercase tracking-widest text-[#f97316]"
                                   onClick={() => handlePronunciation(verse.id, verse.text_uthmani)}
                                   disabled={loadingPronunciation[verse.id]}
                                 >
                                   {loadingPronunciation[verse.id] ? <Loader2 className="animate-spin mr-2" size={14} /> : <Mic size={14} className="mr-2" />}
                                   উচ্চারণ (Pronunciation)
                                 </Button>
                               </div>

                               <div className="flex items-center gap-2">
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className={`rounded-full ${isBookmarked(verse.id) ? 'text-[#f97316]' : 'text-muted-foreground'}`}
                                    onClick={() => toggleBookmark(verse, selectedSurah.name_simple)}
                                  >
                                    <Heart size={18} fill={isBookmarked(verse.id) ? "currentColor" : "none"} />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="rounded-full text-muted-foreground"
                                    onClick={() => {
                                      const translationsText = verse.translations?.map(t => {
                                        const authors: {[key: number]: string} = {
                                          161: 'Taisirul Quran',
                                          162: 'Rawai Al-bayan',
                                          163: 'Sheikh Mujibur Rahman',
                                          213: 'Dr. Abu Bakr Muhammad Zakaria',
                                          131: 'Sahih International'
                                        };
                                        return `${authors[t.resource_id] || 'Translation'}:\n${t.text.replace(/<(?:.|\n)*?>/gm, '')}`;
                                      }).join('\n\n') || '';
                                      navigator.clipboard.writeText(`${verse.text_uthmani}\n\n${translationsText}\n\nFrom Al-Nur Quran`);
                                      safeAlert("Verse copied to clipboard!");
                                    }}
                                  >
                                    <Share2 size={18} />
                                  </Button>
                               </div>
                             </div>

                             {reflection[verse.id] && (
                               <motion.div
                                 initial={{ height: 0, opacity: 0 }}
                                 animate={{ height: 'auto', opacity: 1 }}
                                 className="mt-6 p-6 bg-accent border-l-4 border-[#1d4ed8] rounded-r-2xl overflow-hidden"
                               >
                                  <div className="flex items-start gap-4">
                                     <Info className="text-[#1d4ed8] shrink-0 mt-1" size={18} />
                                     <div>
                                       <p className="text-sm font-bold uppercase tracking-widest text-[#1d4ed8] mb-2">Spiritual Reflection</p>
                                       <p className="text-foreground/80 text-base leading-relaxed">{reflection[verse.id]}</p>
                                     </div>
                                  </div>
                               </motion.div>
                             )}

                             {pronunciation[verse.id] && (
                               <motion.div
                                 initial={{ height: 0, opacity: 0 }}
                                 animate={{ height: 'auto', opacity: 1 }}
                                 className="mt-4 p-6 bg-[#fff7ed] border-l-4 border-[#f97316] rounded-r-2xl overflow-hidden"
                                >
                                  <div className="flex items-start gap-4">
                                     <Mic className="text-[#f97316] shrink-0 mt-1" size={18} />
                                     <div>
                                       <p className="text-sm font-bold uppercase tracking-widest text-[#f97316] mb-2">উচ্চারণ (Pronunciation)</p>
                                       <p className="text-foreground/80 text-lg leading-relaxed font-medium">{pronunciation[verse.id]}</p>
                                     </div>
                                  </div>
                               </motion.div>
                             )}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          ) : (
            <>
              {activeTab === 'search' && (
                 <motion.div
                  key="ai-search"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8"
                 >
                    <div className="flex items-center justify-between">
                       <h2 className="text-2xl font-bold tracking-tight">AI Knowledge Base</h2>
                       <Button variant="ghost" onClick={() => setActiveTab('surahs')} className="rounded-full text-xs font-bold uppercase tracking-widest">
                         Close Results
                       </Button>
                    </div>

                    <Card className="rounded-3xl border-none shadow-xl overflow-hidden bg-card">
                       <CardContent className="p-8 md:p-12">
                          {searchingAI ? (
                             <div className="flex flex-col items-center justify-center py-20 gap-4">
                                <Loader2 size={40} className="animate-spin text-primary" />
                                <p className="text-muted-foreground font-medium animate-pulse">Consulting Quranic Knowledge...</p>
                             </div>
                          ) : geminiSearchResult ? (
                             <div className="prose prose-stone max-w-none prose-headings:font-serif prose-headings:tracking-tight prose-p:leading-relaxed prose-p:text-lg text-foreground/80">
                                <div className="markdown-body">
                                  {geminiSearchResult.split('\n').map((line, i) => (
                                    <p key={i} className="mb-4">{line}</p>
                                  ))}
                                </div>
                                <div className="mt-12 pt-8 border-t flex items-center justify-between">
                                   <p className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">AI Assisted Search</p>
                                   <Button size="sm" onClick={() => { setSearchTerm(''); setActiveTab('surahs'); }} className="rounded-full bg-primary hover:bg-primary/90 shadow-lg">Return to Chapters</Button>
                                </div>
                             </div>
                          ) : (
                             <div className="text-center py-20">
                                <p className="text-muted-foreground">Search for a topic to see AI-powered verse suggestions.</p>
                             </div>
                          )}
                       </CardContent>
                    </Card>
                 </motion.div>
              )}

              {activeTab === 'topics' && (
                <motion.div
                  key="topics-tab"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h2 className="text-3xl font-bold tracking-tight">Topic-based Verses</h2>
                    <div className="relative w-full md:w-64">
                      <SearchIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <Input 
                        placeholder="Filter topics..." 
                        className="pl-10 rounded-full h-10 border-none bg-muted/50 focus:bg-card transition-all"
                        value={topicSearchTerm}
                        onChange={(e) => setTopicSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {TOPICS.filter(t => t.topic.toLowerCase().includes(topicSearchTerm.toLowerCase())).map((item) => (
                      <motion.div
                        key={item.id}
                        layoutId={`topic-${item.id}`}
                        className="group"
                      >
                        <Card className="rounded-[2.5rem] border-none shadow-sm hover:shadow-2xl transition-all duration-500 overflow-hidden bg-card">
                          <CardContent className="p-8">
                            <div className="flex items-center justify-between mb-6">
                              <Badge className={`${item.color} border-none px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest`}>
                                {item.topic}
                              </Badge>
                              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{item.surah}</span>
                            </div>
                            <div className="space-y-6">
                              <p className="font-arabic text-3xl md:text-4xl text-right leading-[2] text-foreground group-hover:text-[#f97316] transition-colors">
                                {item.arabic}
                              </p>
                              <p className="text-lg text-muted-foreground leading-relaxed font-medium">
                                {item.bangla}
                              </p>
                            </div>
                            <div className="mt-8 pt-6 border-t flex items-center justify-between">
                               <div className="flex gap-2">
                                 <Button variant="ghost" size="sm" className="rounded-full text-[10px] uppercase font-bold tracking-widest hover:text-[#f97316]" onClick={() => {
                                   navigator.clipboard.writeText(`${item.arabic}\n\n${item.bangla}\n\nFrom Al-Nur Quran`);
                                   safeAlert("Copied to clipboard!");
                                 }}>
                                   <Share2 size={14} className="mr-2" /> Share
                                 </Button>
                               </div>
                               <Tag size={18} className="text-muted-foreground/20" />
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {activeTab === 'surahs' && (
                <motion.div
                  key="surah-list"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8"
                >
                  {/* Beautiful custom-styled Al-Quraner Alo Banner */}
                  <div className="banner-container">
                    <div className="responsive-banner relative h-[250px] md:h-[320px] lg:h-[360px] w-full overflow-hidden bg-[#0f172a]">
                      {/* Background Image with Overlay */}
                      <div 
                        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-700 hover:scale-105"
                        style={{ 
                          backgroundImage: `url('https://images.unsplash.com/photo-1609599006353-e629f1d29718?q=80&w=1600&auto=format&fit=crop')`,
                        }}
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/65" />
                      
                      {/* Content Overlay */}
                      <div className="absolute inset-0 flex flex-col justify-center items-center text-center p-6 md:p-8 z-10">
                        {/* Bismillah Calligraphy */}
                        <div className="text-amber-400 text-lg md:text-2xl font-serif mb-2 select-none drop-shadow-md">
                          بِسْمِ اللهِ الرَّحْمٰনِ الرَّحِيْمِ
                        </div>

                        {/* Title */}
                        <h1 className="text-3xl md:text-5xl lg:text-6xl font-black text-white tracking-wide font-serif mb-2 drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
                          {language === 'Bangla' ? 'আল-কুরআন আলো' : 'Al-Quran Light'}
                        </h1>

                        {/* Arabic text / Subtitle transliteration */}
                        <div className="text-[10px] md:text-xs tracking-widest text-amber-500/85 uppercase font-sans mb-3 select-none">
                          Hudaa li-al-Muttaqeen
                        </div>

                        {/* Decorative Line */}
                        <div className="h-[2px] w-28 bg-gradient-to-r from-transparent via-amber-400/80 to-transparent mb-3" />

                        {/* Subtitle */}
                        <p className="text-xs md:text-lg text-gray-200 font-light max-w-2xl tracking-wide leading-relaxed drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
                          {language === 'Bangla' ? 'আপনার দৈনন্দিন জীবনের সঠিক নির্দেশিকা' : 'Your ultimate guide for daily life'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-8 mb-12">
                    <div className="relative overflow-hidden rounded-3xl bg-[#0f172a] text-white p-8 md:p-12 shadow-2xl">
                      <div className="relative z-10 max-w-2xl">
                        <Badge className="mb-4 bg-[#f97316] hover:bg-[#ea580c] border-none px-3 py-1 rounded-full text-[10px] uppercase tracking-widest whitespace-nowrap">Featured Insight</Badge>
                        <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 leading-tight text-[#f97316]">
                          "Knowledge of Divine Energy"
                        </h2>
                        <Button className="bg-[#f97316] hover:bg-[#ea580c] text-white rounded-full px-8 h-12 text-base shadow-xl border-none" onClick={handleDailyVerse}>
                          Start Your Journey
                        </Button>
                      </div>
                      {/* Decorative Elements */}
                      <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none overflow-hidden">
                         <div className="absolute -top-12 -right-12 w-96 h-96 border-[40px] border-[#f97316] rounded-full" />
                      </div>
                    </div>
                  </div>

                  <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#111827] to-[#1f2937] text-white p-8 shadow-2xl border border-white/5 flex flex-col md:flex-row gap-6 items-center">
                    {/* Stylized Rooftop Selfie Avatar */}
                    <div className="relative shrink-0">
                      <svg className="w-28 h-28 md:w-32 md:h-32 rounded-full border-4 border-emerald-500 shadow-2xl bg-sky-200 overflow-hidden" viewBox="0 0 100 100">
                        {/* Sky Background */}
                        <rect width="100" height="100" fill="#bae6fd" />
                        {/* White Clouds */}
                        <circle cx="20" cy="30" r="15" fill="#f0f9ff" opacity="0.8" />
                        <circle cx="80" cy="25" r="12" fill="#f0f9ff" opacity="0.8" />
                        
                        {/* Roof Ledge and Green Water Tank in the background */}
                        <rect x="0" y="60" width="100" height="40" fill="#cbd5e1" />
                        {/* Green Water Tank */}
                        <rect x="75" y="45" width="18" height="20" rx="3" fill="#0d9488" />
                        <line x1="75" y1="50" x2="93" y2="50" stroke="#0f766e" strokeWidth="1" />
                        <line x1="75" y1="55" x2="93" y2="55" stroke="#0f766e" strokeWidth="1" />
                        <line x1="75" y1="60" x2="93" y2="60" stroke="#0f766e" strokeWidth="1" />
                        {/* Brick pillar */}
                        <rect x="5" y="50" width="15" height="15" fill="#ca8a04" />
                        <line x1="5" y1="55" x2="20" y2="55" stroke="#a16207" strokeWidth="1" />
                        <line x1="5" y1="60" x2="20" y2="60" stroke="#a16207" strokeWidth="1" />

                        {/* Shoulders / White shirt */}
                        <path d="M 15 100 L 35 75 L 45 78 L 50 82 L 55 78 L 65 75 L 85 100 Z" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1" />
                        {/* Collar lines */}
                        <path d="M 35 75 L 45 84 L 50 82" stroke="#cbd5e1" strokeWidth="1.5" fill="none" />
                        <path d="M 65 75 L 55 84 L 50 82" stroke="#cbd5e1" strokeWidth="1.5" fill="none" />

                        {/* Neck */}
                        <path d="M 42 65 L 42 78 L 58 78 L 58 65 Z" fill="#f3c6a5" />
                        <path d="M 42 74 L 50 81 L 58 74" fill="#e0ab83" opacity="0.5" />

                        {/* Face */}
                        <path d="M 35 45 C 35 30, 65 30, 65 45 C 65 60, 65 68, 50 72 C 35 68, 35 60, 35 45 Z" fill="#fddcb9" />
                        
                        {/* Ears */}
                        <circle cx="34" cy="48" r="4.5" fill="#fddcb9" />
                        <circle cx="66" cy="48" r="4.5" fill="#fddcb9" />

                        {/* Trimmed beard / Mustache */}
                        <path d="M 34 45 C 34 58, 38 71, 50 72.5 C 62 71, 66 58, 66 45 C 64 45, 62 48, 62 55 C 62 62, 58 67, 50 67 C 42 67, 38 62, 38 55 C 38 48, 36 45, 34 45 Z" fill="#1e1b4b" />
                        {/* Mustache */}
                        <path d="M 42 56 C 45 54, 55 54, 58 56 C 58 58, 55 58, 50 59 C 45 58, 42 58, 42 56 Z" fill="#1e1b4b" />
                        <path d="M 46 62.5 C 48 62, 52 62, 54 62.5 C 53 63.5, 47 63.5, 46 62.5 Z" fill="#1e1b4b" />

                        {/* Hair */}
                        <path d="M 35 42 C 34 33, 40 28, 50 28 C 60 28, 66 33, 65 42 C 61 38, 57 37, 50 37 C 43 37, 39 38, 35 42 Z" fill="#1e1b4b" />
                        
                        {/* Eyes */}
                        <ellipse cx="44" cy="46" rx="2.5" ry="1.5" fill="#0f172a" />
                        <ellipse cx="56" cy="46" rx="2.5" ry="1.5" fill="#0f172a" />
                        {/* Eyebrows */}
                        <path d="M 40 43 C 42 41, 47 42, 48 43" stroke="#1e1b4b" strokeWidth="1.5" strokeLinecap="round" fill="none" />
                        <path d="M 60 43 C 58 41, 53 42, 52 43" stroke="#1e1b4b" strokeWidth="1.5" strokeLinecap="round" fill="none" />

                        {/* Nose */}
                        <path d="M 49 45 L 49 52 C 49 53.5, 51 53.5, 51 52 L 51 45" stroke="#e0ab83" strokeWidth="1.2" strokeLinecap="round" fill="none" />

                        {/* Smile */}
                        <path d="M 47 60 Q 50 61 53 60" stroke="#e0ab83" strokeWidth="1" fill="none" />
                      </svg>
                      {/* Interactive Heart Badge overlay */}
                      <motion.div 
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={sendBlessing}
                        className="absolute -bottom-2 -right-2 bg-rose-600 hover:bg-rose-500 text-white p-2.5 rounded-full shadow-lg cursor-pointer flex items-center justify-center border-2 border-white"
                      >
                        <Heart size={16} fill="white" className="animate-pulse" />
                      </motion.div>
                    </div>

                    {/* Info Container */}
                    <div className="flex-1 space-y-3 text-left">
                      <div>
                        <Badge className="bg-emerald-500 hover:bg-emerald-600 text-white text-[9px] tracking-widest uppercase font-bold px-2.5 py-0.5 rounded-full border-none mb-1">
                          {language === 'Bangla' ? 'প্রতিষ্ঠাতা ও বিকাশকারী' : 'Founder & Developer'}
                        </Badge>
                        <h3 className="text-2xl font-serif font-black tracking-tight flex items-center gap-2">
                          MD Azad Sardar <span className="bg-[#f6fef6] text-[#d40031] font-sans text-xs font-semibold">(Ajad)</span>
                        </h3>
                      </div>

                      <p className="text-gray-300 text-xs font-light leading-relaxed">
                        {language === 'Bangla' 
                          ? 'আল-নূর কুরআন অ্যাপটি পরম মমতায় তৈরি করেছেন আজাদ সরদার। তার লক্ষ্য আধুনিক প্রযুক্তির মাধ্যমে পবিত্র কুরআনের আলো ঘরে ঘরে পৌঁছে দেওয়া এবং মানুষের হৃদয় আলোকিত করা।'
                          : 'Al-Nur Quran is lovingly developed by Azad Sardar. His mission is to illuminate hearts and bring the divine teachings of the Holy Quran closer to everyone using modern, beautiful, and intuitive designs.'}
                      </p>

                      <div className="flex items-center gap-4 pt-1 flex-wrap">
                        <div className="flex items-center gap-1.5 text-xs text-rose-400 font-bold bg-rose-500/10 px-3 py-1.5 rounded-full border border-rose-500/20">
                          <Heart size={14} fill="currentColor" />
                          <span>{blessingsCount.toLocaleString()} {language === 'Bangla' ? 'টি দুআ ও ভালোবাসা' : 'Blessings Sent'}</span>
                        </div>
                        
                        <a 
                          href="mailto:mdazadsardar@gmail.com"
                          className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 px-3 py-1.5 rounded-full border border-emerald-500/20 transition-all flex items-center gap-1"
                        >
                          <Mail size={12} />
                          Contact
                        </a>
                      </div>
                    </div>
                  </div>

                  {language === 'Bangla' && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      className="mb-12 bg-white dark:bg-card p-10 rounded-[2.5rem] shadow-xl border border-muted"
                    >
                      <div className="text-center border-bottom border-muted pb-8 mb-8">
                        <h2 className="text-[#2c3e50] dark:text-[#f97316] font-bold text-3xl mb-2">সূরা আত-ত্বলাক (আয়াত: ১২)</h2>
                        <p className="text-muted-foreground/60 uppercase tracking-widest text-[10px] font-black">পবিত্ৰ কুরআনের বিভিন্ন বাংলা অনুবাদ</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {[
                          { 
                            author: 'Taisirul Quran', 
                            text: 'আল্লাহই সাত আসমান বানিয়েছেন আর ওগুলোর মত পৃথিবীও, সবগুলোর মাঝে (অর্থাৎ সকল আসমানে আর সকল যমীনে) নেমে আসে আল্লাহর নির্দেশ যাতে তোমরা জানতে পার যে, আল্লাহ সব কিছুর উপর ক্ষমতাবান আর আল্লাহ (স্বীয়) জ্ঞানে সব কিছুকে ঘিরে রেখেছেন।' 
                          },
                          { 
                            author: 'Sheikh Mujibur Rahman', 
                            text: 'আল্লাহই সৃষ্টি করেছেন সপ্ত আকাশ এবং পৃথিবীও সেই পরিমাণ। ওগুলির মধ্যে নেমে আসে তাঁর নির্দেশ; ফলে তোমরা বুঝতে পার যে, আল্লাহ সর্ব বিষয়ে সর্বশক্তিমান এবং জ্ঞানে আল্লাহ সব কিছুকে পরিবেষ্টন করে রয়েছেন।' 
                          },
                          { 
                            author: 'Rawai Al-bayan', 
                            text: 'তিনি আল্লাহ, যিনি সাত আসমান এবং অনুরূপ যমীন সৃষ্টি করেছেন; এগুলি মাঝে তাঁর নির্দেশ অবতীর্ণ হয় যেন তোমরা জানতে পার যে, আল্লাহ সর্ববিষয়ে ক্ষমতাবান এবং আল্লাহর জ্ঞানতো সব কিছুকে বেষ্টন করে আছে।' 
                          },
                          { 
                            author: 'Dr. Abu Bakr Muhammad Zakaria', 
                            text: 'তিনি আল্লাহ্, যিনি সৃষ্টি করেছেন সাত আসমান এবং অনুরূপ যমীন, তাদের মধ্যে নেমে আসে তাঁর নির্দেশ; যাতে তোমরা জানতে পার যে, আল্লাহ সবকিছুর উপর ক্ষমতাবান এবং জ্ঞানে আল্লাহ্ সবকিছুকে পরিবেষ্টন করে আছেন।' 
                          }
                        ].map((t, i) => (
                          <div 
                            key={i} 
                            className="bg-[#fafafa] dark:bg-muted/10 border-l-[4px] border-[#16a085] p-6 rounded-r-2xl transition-transform hover:translate-x-2 duration-300"
                          >
                            <p className="text-[#16a085] font-black text-[10px] uppercase tracking-widest mb-3 opacity-80">— {t.author}</p>
                            <p className="text-[#2c3e50] dark:text-foreground/80 leading-relaxed font-medium">{t.text}</p>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                      <h2 className="text-2xl font-bold tracking-tight">Browse Chapters</h2>
                      <div className="flex gap-4">
                        <Badge variant="secondary" className="px-3 py-1 bg-card shadow-sm border-none text-[10px] uppercase tracking-widest font-bold">
                          <span className="text-[#1d4ed8] mr-1">{filteredSurahs.length === 114 ? '114' : `${filteredSurahs.length} / 114`}</span> Chapters
                        </Badge>
                        <Badge variant="secondary" className="px-3 py-1 bg-card shadow-sm border-none text-[10px] uppercase tracking-widest font-bold">
                          <span className="text-[#f97316] mr-1">
                            {filteredSurahs.length === 114 ? '6,236' : filteredSurahs.reduce((acc, curr) => acc + curr.verses_count, 0).toLocaleString()}
                          </span> Verses
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {language === 'Bangla' && !searchTerm && (
                      <motion.div
                        whileHover={{ scale: 1.02, y: -4 }}
                        className="group"
                        onClick={toggleBengaliCollection}
                      >
                        <Card className={`cursor-pointer border-none shadow-md hover:shadow-2xl transition-all duration-300 rounded-2xl overflow-hidden ${showBengaliCollection ? 'bg-[#f97316] text-white' : 'bg-[#fff7ed] border-[#f97316]/20 border'}`}>
                          <CardContent className="p-5 flex items-center justify-between h-full">
                            <div className="flex items-center gap-4">
                              <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xl transition-colors ${showBengaliCollection ? 'bg-white/20 text-white' : 'bg-[#f97316] text-white'}`}>
                                <Folder size={24} />
                              </div>
                              <div>
                                <h3 className="font-bold text-xl leading-tight">নতুন ফোল্ডার</h3>
                                <p className={`text-sm font-medium uppercase tracking-tight ${showBengaliCollection ? 'text-white/80' : 'text-[#f97316]'}`}>Bengali Collection</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge className={showBengaliCollection ? "bg-white text-[#f97316]" : "bg-[#f97316] text-white"}>
                                {showBengaliCollection ? "Active" : "Open"}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    )}
                    {loadingSurahs ? (
                      Array.from({ length: 12 }).map((_, i) => (
                        <Skeleton key={i} className="h-32 rounded-2xl" />
                      ))
                    ) : filteredSurahs.length > 0 ? (
                      filteredSurahs.map((surah) => (
                      <motion.div
                        key={surah.id}
                        whileHover={{ scale: 1.02, y: -4 }}
                        className="group"
                        onClick={() => setSelectedSurah(surah)}
                      >
                        <Card className="cursor-pointer border-none shadow-sm hover:shadow-xl transition-all duration-300 rounded-2xl overflow-hidden bg-accent/40 group-hover:bg-accent border-muted/20 border">
                          <CardContent className="p-5 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 rounded-xl bg-background shadow-sm flex items-center justify-center font-serif text-[#1d4ed8] font-bold text-xl group-hover:bg-[#1d4ed8] group-hover:text-white transition-colors">
                                {surah.id}
                              </div>
                              <div>
                                <h3 className="font-bold text-xl leading-tight group-hover:text-[#1d4ed8] transition-colors">{surah.name_simple}</h3>
                                <p className="text-sm text-muted-foreground font-medium uppercase tracking-tight">{surah.translated_name.name}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-arabic text-3xl text-foreground/80 mb-1 group-hover:text-[#f97316] transition-colors">{surah.name_arabic}</p>
                              <p className="text-xs text-muted-foreground font-bold">{surah.verses_count} Verses</p>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))
                    ) : (
                      <div className="col-span-full py-20 text-center">
                        <div className="w-20 h-20 bg-muted/30 rounded-full flex items-center justify-center mx-auto mb-4">
                          <SearchIcon size={32} className="text-muted-foreground/50" />
                        </div>
                        <h3 className="text-xl font-bold mb-2">No Chapters Found</h3>
                        <p className="text-muted-foreground">Try searching with a different name or use AI search for topics.</p>
                        <Button variant="outline" className="mt-6 rounded-full" onClick={() => setSearchTerm('')}>Clear Search</Button>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </>
          )}
        </AnimatePresence>
      </main>

      {/* Global Audio Controller */}
      <AnimatePresence>
        {isPlaying && (
            <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-lg bg-[#0f172a] text-white rounded-[2rem] p-4 shadow-[0_32px_64px_-12px_rgba(37,99,235,0.3)] flex items-center justify-between"
           >
              <div className="flex items-center gap-4 pl-4">
                 <div className="w-12 h-12 bg-[#f97316] rounded-2xl flex items-center justify-center animate-pulse">
                    <Headphones size={22} />
                 </div>
                 <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground font-bold">Currently Reciting</p>
                    <p className="font-bold text-sm">{selectedSurah?.name_simple}</p>
                 </div>
              </div>
              <div className="flex items-center gap-2 pr-2">
                 <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10" onClick={toggleAudio}>
                    <Pause size={24} fill="currentColor" />
                 </Button>
                 <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10" onClick={() => { if(currentAudio) { currentAudio.pause(); } setIsPlaying(false); }}>
                    <X size={24} />
                 </Button>
              </div>
           </motion.div>
        )}
      </AnimatePresence>

      <footer className="bg-card border-t py-16 mt-20">
         <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-2">
               <div className="flex items-center gap-3 mb-6 font-serif">
                <div className="w-8 h-8 bg-[#1d4ed8] rounded-lg flex items-center justify-center text-white">
                  <Book size={18} fill="currentColor" />
                </div>
                <h2 className="font-black text-xl tracking-tighter"><span className="text-[#1d4ed8]">Al-Nur</span> <span className="text-[#f97316]">Quran</span></h2>
              </div>
              <p className="text-muted-foreground max-w-sm mb-4 leading-relaxed">
                Our mission is to harness modern technology to bring the eternal message of the Holy Quran to every screen. We provide authentic Arabic text, multi-language translations, and spiritual insights to make the Quran accessible to all.
              </p>
              <div className="space-y-1 mb-6 text-sm font-medium">
                <p className="flex items-center gap-2 text-[#1d4ed8]">
                   <span className="text-muted-foreground">Phone:</span> +91 8346042799
                </p>
                <p className="flex items-center gap-2 text-[#1d4ed8]">
                   <span className="text-muted-foreground">Email:</span> mdazadsardar@gmail.com
                </p>
              </div>
              <div className="flex gap-4">
                 <Button variant="outline" size="sm" className="rounded-full hover:border-[#f97316] hover:text-[#f97316]">Privacy Policy</Button>
                 <Button variant="outline" size="sm" className="rounded-full hover:border-[#1d4ed8] hover:text-[#1d4ed8]" onClick={() => window.location.href = 'mailto:mdazadsardar@gmail.com'}>Contact Us</Button>
              </div>
            </div>
            <div>
               <h4 className="font-bold text-sm uppercase tracking-widest mb-6 text-[#1d4ed8]">Community</h4>
               <ul className="space-y-4 text-sm text-muted-foreground font-medium">
                  <li className="hover:text-[#f97316] cursor-pointer transition-colors">About Us</li>
                  <li className="hover:text-[#f97316] cursor-pointer transition-colors">Support Our Mission</li>
                  <li className="hover:text-[#f97316] cursor-pointer transition-colors">Newsletter</li>
                  <li className="hover:text-[#f97316] cursor-pointer transition-colors">Careers</li>
               </ul>
            </div>
         </div>
         <div className="max-w-7xl mx-auto px-4 mt-16 pt-8 border-t flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] uppercase tracking-widest font-bold text-muted-foreground/40">
            <p>© 2026 Al-Nur Quran. All rights reserved.</p>
            <p>Brought to you with love and devotion by <span className="text-[#f97316]">Ajad Portfolio</span>.</p>
         </div>
      </footer>
    </div>
  );
}
