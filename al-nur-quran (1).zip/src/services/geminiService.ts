export const geminiService = {
  getInsights: async (verseText: string, context: string): Promise<string | null> => {
    try {
      const response = await fetch("/api/gemini/insights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ verseText, context }),
      });
      
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || `HTTP error ${response.status}`);
      }
      
      const data = await response.json();
      return data.text || null;
    } catch (error) {
      console.error("Gemini Insights Proxy Error:", error);
      return null;
    }
  },

  searchVerses: async (query: string): Promise<string | null> => {
    try {
      const response = await fetch("/api/gemini/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      });
      
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || `HTTP error ${response.status}`);
      }
      
      const data = await response.json();
      return data.text || null;
    } catch (error) {
       console.error("Gemini Search Proxy Error:", error);
       return null;
    }
  },

  getPronunciation: async (arabicText: string): Promise<string | null> => {
    try {
      const response = await fetch("/api/gemini/pronunciation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ arabicText }),
      });
      
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || `HTTP error ${response.status}`);
      }
      
      const data = await response.json();
      return data.text || null;
    } catch (error) {
      console.error("Gemini Pronunciation Proxy Error:", error);
      return null;
    }
  }
};
