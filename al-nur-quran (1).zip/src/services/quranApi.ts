/**
 * Quran API Service
 * Using api.quran.com
 */

export interface Surah {
  id: number;
  revelation_place: string;
  revelation_order: number;
  bismillah_pre: boolean;
  name_complex: string;
  name_arabic: string;
  name_simple: string;
  verses_count: number;
  pages: number[];
  translated_name: {
    language_name: string;
    name: string;
  };
}

export interface Verse {
  id: number;
  verse_number: number;
  verse_key: string;
  text_uthmani: string;
  translations?: VerseTranslation[];
  words?: Word[];
}

export interface Word {
  id: number;
  position: number;
  text_uthmani: string;
  translation?: {
    text: string;
    language_name: string;
  };
}

export interface VerseTranslation {
  resource_id: number;
  text: string;
}

const BASE_URL = 'https://api.quran.com/api/v4';

export const quranApi = {
  getSurahs: async (language: string = 'en'): Promise<Surah[]> => {
    const response = await fetch(`${BASE_URL}/chapters?language=${language}`);
    const data = await response.json();
    return data.chapters;
  },

  getSurah: async (id: number, language: string = 'en'): Promise<Surah> => {
    const response = await fetch(`${BASE_URL}/chapters/${id}?language=${language}`);
    const data = await response.json();
    return data.chapter;
  },

  getVerses: async (surahId: number, translationId: number | string = 131): Promise<Verse[]> => {
    // 131 is Sahih International (English)
    // Bengali IDs: 161 (Taisirul), 162 (Rawai), 163 (Mujibur), 213 (Abu Bakr Zakaria)
    const bengaliIds = [161, 162, 163, 213];
    const isBengali = typeof translationId === 'number' 
      ? bengaliIds.includes(translationId) 
      : translationId.split(',').some(id => bengaliIds.includes(parseInt(id)));
      
    const wordLang = isBengali ? 'bn' : 'en';
    const response = await fetch(
      `${BASE_URL}/verses/by_chapter/${surahId}?language=${wordLang}&words=true&word_fields=text_uthmani,location&translations=${translationId}&fields=text_uthmani&per_page=300`
    );
    const data = await response.json();
    return data.verses;
  },

  getAudioUrl: (surahId: number, reciterSlug: string = 'mishari_rashid_al-afasy'): string => {
    return `https://download.quranicaudio.com/quran/${reciterSlug}/${surahId.toString().padStart(3, '0')}.mp3`;
  },

  getVerseAudioUrl: (surahId: number, verseNumber: number, reciterSlug: string = 'mishari_rashid_al-afasy'): string => {
    const surahPadded = surahId.toString().padStart(3, '0');
    const versePadded = verseNumber.toString().padStart(3, '0');
    let folder = 'Alafasy_128kbps';
    if (reciterSlug === 'abdul_basit_murattal') {
      folder = 'Abdul_Basit_Murattal_192kbps';
    } else if (reciterSlug === 'abdurrahmaan_as-sudays') {
      folder = 'Abdurrahmaan_As-Sudais_192kbps';
    } else if (reciterSlug === 'abu_bakr_al-shatri') {
      folder = 'Abu_Bakr_Al_Shatri_128kbps';
    } else if (reciterSlug === 'ahmed_ibn_ali_al-ajamy') {
      folder = 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net';
    }
    return `https://www.everyayah.com/data/${folder}/${surahPadded}${versePadded}.mp3`;
  },

  getReciters: async () => {
    const response = await fetch(`${BASE_URL}/resources/recitations`);
    const data = await response.json();
    return data.recitations;
  },

  getTranslations: async () => {
    const response = await fetch(`${BASE_URL}/resources/translations`);
    const data = await response.json();
    return data.translations;
  }
};
